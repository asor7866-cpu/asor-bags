/**
 * packages/types/src/product.ts
 *
 * Single source of truth for the unified product shape.
 * Every scraper output, API response, and frontend prop MUST conform to this.
 */

export type SourcePlatform = "BZ_BAGS" | "ELITE_BAG" | "RANEEN_THREE_M";

export type CategoryMapped =
  | "BACKPACKS"
  | "TRAVEL_BAGS"
  | "CROSSBODY"
  | "HANDBAGS"
  | "LAPTOP_BAGS"
  | "ACCESSORIES"
  | "UNCATEGORIZED";

export interface UnifiedProduct {
  id: string; // UUID, generated at normalization time
  sku: string; // source SKU if available, else a stable synthetic key
  title: string;
  slug: string;
  description: string | null;
  priceEgp: number; // always in EGP, always a float, never a formatted string
  oldPriceEgp: number | null;
  discountPercentage: number | null; // derived, 0-100, null if no discount
  images: string[]; // absolute URLs only
  sourcePlatform: SourcePlatform;
  originalUrl: string;
  categoryMapped: CategoryMapped;
  inStock: boolean;
  ratingAverage: number | null; // 0-5, null if source has no rating data
  ratingCount: number | null;
  scrapedAt: string; // ISO 8601
  updatedAt: string; // ISO 8601
}

/**
 * Raw shape a scraper is allowed to emit before normalization.
 * Deliberately looser than UnifiedProduct — normalization enforces the contract.
 */
export interface RawScrapedProduct {
  sourceSku: string | null;
  title: string;
  descriptionHtml: string | null;
  priceText: string; // e.g. "1,250 EGP" or "EGP 1,250.00"
  oldPriceText: string | null;
  imageUrls: string[];
  sourcePlatform: SourcePlatform;
  originalUrl: string;
  rawCategoryLabel: string | null;
  inStock: boolean;
  ratingAverage: number | null;
  ratingCount: number | null;
}

export interface FacetedSearchParams {
  q?: string;
  minPrice?: number;
  maxPrice?: number;
  sources?: SourcePlatform[];
  categories?: CategoryMapped[];
  inStockOnly?: boolean;
  sort?: "PRICE_ASC" | "PRICE_DESC" | "TOP_RATED" | "NEWEST";
  page?: number;
  pageSize?: number;
}

export interface FacetedSearchResult {
  items: UnifiedProduct[];
  total: number;
  page: number;
  pageSize: number;
  facets: {
    sources: Record<SourcePlatform, number>;
    categories: Record<CategoryMapped, number>;
    priceHistogram: { bucketStart: number; bucketEnd: number; count: number }[];
  };
}
