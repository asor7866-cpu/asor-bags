/**
 * packages/scraper/src/scrapers/elite-bag.scraper.ts
 *
 * Target: https://elite-bag.com/
 * Platform detected live: WordPress + WooCommerce, Porto theme (WPBakery).
 * That means the DOM follows WooCommerce's standard loop markup
 * (ul.products > li.product...), which is what the selectors below target,
 * with defensive fallbacks in case the theme overrides class names on a
 * future redesign.
 *
 * Strategy:
 *   1. Discover every category from the site's known taxonomy (or the nav).
 *   2. Crawl /shop/ (all products) with WooCommerce's ?paged=N pagination —
 *      this alone covers the full catalog; per-category crawl is kept as a
 *      fallback path for sites where /shop/ is disabled.
 *   3. For each product card in the loop, extract everything the catalog
 *      view exposes without a full page-per-product visit (fast path).
 *   4. Optionally hydrate any product missing images/SKU by visiting its
 *      product page directly (slow path, used only for gaps).
 */

import type { Page } from "playwright";
import type { RawScrapedProduct } from "@bags-aggregator/types/product";
import {
  launchStealthBrowser,
  parseEgpPrice,
  safeGoto,
  withRetry,
} from "../lib/utils";

const BASE_URL = "https://elite-bag.com";
const SHOP_URL = `${BASE_URL}/shop/`;

const KNOWN_CATEGORY_SLUGS = [
  "backpack",
  "cross-bag",
  "imported-bags",
  "laptop-bag",
  "mini-bags",
  "school-bags",
  "shoulder-bags",
  "sleeve-bags",
] as const;

interface EliteBagScrapeOptions {
  headless?: boolean;
  maxPagesPerCategory?: number; // safety cap against infinite pagination bugs
  concurrency?: number; // number of category crawls to run in parallel
}

export class EliteBagScraper {
  private readonly options: Required<EliteBagScrapeOptions>;

  constructor(options: EliteBagScrapeOptions = {}) {
    this.options = {
      headless: options.headless ?? true,
      maxPagesPerCategory: options.maxPagesPerCategory ?? 50,
      concurrency: options.concurrency ?? 3,
    };
  }

  /**
   * Entry point. Returns every product found across the full catalog.
   * De-duplicates by originalUrl since /shop/ and per-category pages overlap.
   */
  public async scrapeAll(): Promise<RawScrapedProduct[]> {
    const { browser, context } = await launchStealthBrowser({
      headless: this.options.headless,
    });

    const seen = new Map<string, RawScrapedProduct>();

    try {
      // Primary path: the flat /shop/ listing covers the entire catalog
      // regardless of category, so we walk it first.
      const shopProducts = await this.crawlPaginatedListing(context, SHOP_URL);
      for (const product of shopProducts) seen.set(product.originalUrl, product);

      // Fallback / cross-check path: walk each known category too. This
      // catches products excluded from the main /shop/ loop by theme
      // configuration (some Porto setups hide certain categories there)
      // and lets us assign a reliable rawCategoryLabel per product.
      const categoryBatches = chunk(
        [...KNOWN_CATEGORY_SLUGS],
        this.options.concurrency
      );

      for (const batch of categoryBatches) {
        await Promise.all(
          batch.map(async (slug) => {
            const url = `${BASE_URL}/product-category/${slug}/`;
            const products = await this.crawlPaginatedListing(context, url, slug);
            for (const product of products) {
              const existing = seen.get(product.originalUrl);
              if (existing && !existing.rawCategoryLabel) {
                existing.rawCategoryLabel = product.rawCategoryLabel;
              } else if (!existing) {
                seen.set(product.originalUrl, product);
              }
            }
          })
        );
      }
    } finally {
      await context.close();
      await browser.close();
    }

    return [...seen.values()];
  }

  /**
   * Walks WooCommerce's `?paged=N` pagination for a single listing URL
   * (either the flat shop or a single category) until an empty page or the
   * safety cap is hit.
   */
  private async crawlPaginatedListing(
    context: Awaited<ReturnType<typeof launchStealthBrowser>>["context"],
    listingUrl: string,
    categoryHint?: string
  ): Promise<RawScrapedProduct[]> {
    const page = await context.newPage();
    const results: RawScrapedProduct[] = [];

    try {
      for (let pageNum = 1; pageNum <= this.options.maxPagesPerCategory; pageNum++) {
        const url = pageNum === 1 ? listingUrl : `${listingUrl}page/${pageNum}/`;

        try {
          await safeGoto(page, url, { waitUntil: "domcontentloaded" });
        } catch {
          // A 404 on page/N/ means we've walked past the last page — normal
          // termination, not an error worth surfacing.
          break;
        }

        const notFound = await page
          .locator("body.error404")
          .count()
          .then((n) => n > 0);
        if (notFound) break;

        await withRetry(
          () => page.waitForSelector("ul.products, .woocommerce-info", { timeout: 15_000 }),
          { label: `wait for product loop on ${url}`, retries: 2 }
        );

        const noProductsBanner = await page.locator(".woocommerce-info").count();
        const cardLocator = page.locator("ul.products > li.product");
        const cardCount = await cardLocator.count();

        if (cardCount === 0 || noProductsBanner > 0) break;

        const pageProducts = await this.extractCardsFromCurrentPage(page, categoryHint);
        results.push(...pageProducts);

        const hasNextPage = await page.locator("a.next.page-numbers").count();
        if (hasNextPage === 0) break;
      }
    } finally {
      await page.close();
    }

    return results;
  }

  /**
   * Extracts every product card already rendered on the current listing
   * page. Uses layered selector fallbacks since WooCommerce themes
   * frequently wrap the same semantic markup in different class names.
   */
  private async extractCardsFromCurrentPage(
    page: Page,
    categoryHint?: string
  ): Promise<RawScrapedProduct[]> {
    return page.$$eval(
      "ul.products > li.product",
      (cards, categoryHintInner) =>
        cards.map((card) => {
          const text = (sel: string): string | null =>
            card.querySelector(sel)?.textContent?.trim() ?? null;

          const attr = (sel: string, name: string): string | null =>
            card.querySelector(sel)?.getAttribute(name) ?? null;

          // --- Link + title: try the canonical WooCommerce/Porto classes,
          // then fall back to "any anchor wrapping the product title".
          const linkEl =
            card.querySelector<HTMLAnchorElement>("a.woocommerce-LoopProduct-link") ??
            card.querySelector<HTMLAnchorElement>("a.woocommerce-loop-product__link") ??
            card.querySelector<HTMLAnchorElement>("a[href]");

          const originalUrl = linkEl?.href ?? "";

          const title =
            text(".woocommerce-loop-product__title") ??
            text("h2.woocommerce-loop-product__title") ??
            text("h2") ??
            linkEl?.getAttribute("aria-label") ??
            "Untitled product";

          // --- Price block: WooCommerce renders <del> (old price) and
          // <ins> (current price) inside .price when a sale is active,
          // otherwise a single <span class="woocommerce-Price-amount">.
          const priceContainer = card.querySelector(".price");
          const delPrice = priceContainer?.querySelector("del .woocommerce-Price-amount")
            ?.textContent?.trim();
          const insPrice = priceContainer?.querySelector("ins .woocommerce-Price-amount")
            ?.textContent?.trim();
          const singlePrice = priceContainer?.querySelector(".woocommerce-Price-amount")
            ?.textContent?.trim();
          const rawPriceFallback = priceContainer?.textContent?.trim() ?? "";

          const priceText = insPrice ?? singlePrice ?? rawPriceFallback;
          const oldPriceText = delPrice ?? null;

          // --- Images: WooCommerce loop images are usually the thumbnail
          // size; grab every <img> in the card and de-duplicate by src.
          const imageUrls = [...card.querySelectorAll<HTMLImageElement>("img")]
            .map((img) => img.getAttribute("data-src") ?? img.src)
            .filter((src): src is string => Boolean(src) && !src.includes("placeholder"));

          // --- Category: prefer the explicit taxonomy link rendered in the
          // card (Porto shows it above the title), fall back to the hint
          // passed in from the category-crawl caller.
          const categoryLink = card.querySelector<HTMLAnchorElement>(
            'a[href*="/product-category/"]'
          );
          const rawCategoryLabel =
            categoryLink?.textContent?.trim() ?? categoryHintInner ?? null;

          const outOfStock =
            card.classList.contains("outofstock") ||
            Boolean(card.querySelector(".out-of-stock, .outofstock"));

          const ratingEl = card.querySelector(".star-rating");
          const ratingStyle = ratingEl?.getAttribute("style") ?? "";
          const ratingWidthMatch = ratingStyle.match(/width:\s*([\d.]+)%/);
          const ratingAverage = ratingWidthMatch
            ? Math.round((Number.parseFloat(ratingWidthMatch[1]) / 100) * 5 * 10) / 10
            : null;

          const skuFromDataAttr = attr("[data-product_sku]", "data-product_sku");

          return {
            sourceSku: skuFromDataAttr,
            title,
            descriptionHtml: null, // catalog view has no description; hydrated separately if needed
            priceText: priceText ?? "",
            oldPriceText,
            imageUrls,
            sourcePlatform: "ELITE_BAG" as const,
            originalUrl,
            rawCategoryLabel,
            inStock: !outOfStock,
            ratingAverage,
            ratingCount: null, // not exposed at catalog-card level
          };
        }),
      categoryHint ?? null
    );
  }

  /**
   * Slow-path hydration: visits a single product page to fill in fields the
   * catalog card doesn't expose (full description, exact SKU, review count).
   * Call this selectively — e.g. only for products missing a SKU — rather
   * than for the whole catalog, to keep run time reasonable.
   */
  public async hydrateProductDetail(
    context: Awaited<ReturnType<typeof launchStealthBrowser>>["context"],
    productUrl: string
  ): Promise<Partial<RawScrapedProduct>> {
    const page = await context.newPage();
    try {
      await safeGoto(page, productUrl, { waitUntil: "domcontentloaded" });
      await withRetry(() => page.waitForSelector(".summary", { timeout: 15_000 }), {
        label: `product detail ${productUrl}`,
      });

      return page.$eval(".summary", (summary) => {
        const sku = summary.querySelector(".sku")?.textContent?.trim() ?? null;
        const description =
          document.querySelector("#tab-description")?.innerHTML.trim() ?? null;
        const reviewCountText = summary
          .querySelector(".woocommerce-review-link")
          ?.textContent?.trim();
        const reviewCountMatch = reviewCountText?.match(/(\d+)/);

        return {
          sourceSku: sku,
          descriptionHtml: description,
          ratingCount: reviewCountMatch ? Number.parseInt(reviewCountMatch[1], 10) : null,
        };
      });
    } finally {
      await page.close();
    }
  }
}

function chunk<T>(items: T[], size: number): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < items.length; i += size) out.push(items.slice(i, i + size));
  return out;
}

/**
 * Normalizes raw scraped rows into the strict UnifiedProduct contract.
 * Kept in this file (rather than a shared normalizer) only for the parts
 * that are Elite-Bag-specific — category mapping. Price/discount math is
 * shared via lib/utils so every scraper computes it identically.
 */
export function mapEliteCategoryToUnified(
  rawLabel: string | null
): "BACKPACKS" | "TRAVEL_BAGS" | "CROSSBODY" | "HANDBAGS" | "LAPTOP_BAGS" | "ACCESSORIES" | "UNCATEGORIZED" {
  if (!rawLabel) return "UNCATEGORIZED";
  const normalized = rawLabel.toLowerCase();

  if (normalized.includes("backpack")) return "BACKPACKS";
  if (normalized.includes("cross")) return "CROSSBODY";
  if (normalized.includes("laptop") || normalized.includes("sleeve")) return "LAPTOP_BAGS";
  if (normalized.includes("shoulder") || normalized.includes("mini")) return "HANDBAGS";
  if (normalized.includes("school") || normalized.includes("imported")) return "TRAVEL_BAGS";
  return "ACCESSORIES";
}

/**
 * Example standalone run:
 *
 *   const scraper = new EliteBagScraper({ headless: true, concurrency: 3 });
 *   const rawProducts = await scraper.scrapeAll();
 *   console.log(`Scraped ${rawProducts.length} products from Elite Bag`);
 */
