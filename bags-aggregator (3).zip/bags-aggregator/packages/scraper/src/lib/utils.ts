/**
 * packages/scraper/src/lib/utils.ts
 *
 * Shared low-level helpers used by every site-specific scraper.
 * Kept dependency-light and pure where possible so they're easy to unit test.
 */

import type { Browser, BrowserContext, Page } from "playwright";
import { chromium } from "playwright-extra";
import StealthPlugin from "puppeteer-extra-plugin-stealth";

chromium.use(StealthPlugin());

export interface LaunchOptions {
  headless?: boolean;
  proxy?: { server: string; username?: string; password?: string };
  userAgent?: string;
}

const DEFAULT_UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
  "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

/**
 * Launches a stealth-hardened Chromium instance shared across a scrape run.
 * Cloudflare / basic bot-fingerprint checks are the target threat model here —
 * this is NOT a guarantee against advanced managed challenge pages, which
 * require a captcha-solving service and are out of scope for this pipeline.
 */
export async function launchStealthBrowser(
  opts: LaunchOptions = {}
): Promise<{ browser: Browser; context: BrowserContext }> {
  const browser = await chromium.launch({
    headless: opts.headless ?? true,
    proxy: opts.proxy,
    args: [
      "--disable-blink-features=AutomationControlled",
      "--disable-dev-shm-usage",
      "--no-sandbox",
    ],
  });

  const context = await browser.newContext({
    userAgent: opts.userAgent ?? DEFAULT_UA,
    viewport: { width: 1366, height: 900 },
    locale: "en-US",
    timezoneId: "Africa/Cairo",
  });

  // Trim obvious automation fingerprints beyond what the stealth plugin covers.
  await context.addInitScript(() => {
    Object.defineProperty(navigator, "webdriver", { get: () => undefined });
  });

  return { browser, context };
}

/**
 * Runs an async operation with exponential backoff. Used for every
 * network-bound step (page.goto, page.waitForSelector, etc.) so a single
 * flaky response doesn't fail an entire scrape job.
 */
export async function withRetry<T>(
  operation: () => Promise<T>,
  opts: { retries?: number; baseDelayMs?: number; label?: string } = {}
): Promise<T> {
  const retries = opts.retries ?? 3;
  const baseDelayMs = opts.baseDelayMs ?? 800;
  let lastError: unknown;

  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      return await operation();
    } catch (err) {
      lastError = err;
      if (attempt === retries) break;
      const delay = baseDelayMs * 2 ** attempt + Math.floor(Math.random() * 250);
      // eslint-disable-next-line no-console
      console.warn(
        `[withRetry] ${opts.label ?? "operation"} failed (attempt ${attempt + 1}/${retries + 1}): ${
          (err as Error).message
        }. Retrying in ${delay}ms.`
      );
      await new Promise((resolve) => setTimeout(resolve, delay));
    }
  }
  throw lastError;
}

/**
 * Parses a raw price string into a float in EGP.
 * Handles every format observed across the three target sources:
 *   "340 EGP"            -> 340
 *   "EGP 1,250.00"        -> 1250.00
 *   "1.950 EGP"           -> 1950        (Egyptian dot-as-thousands-separator)
 *   "490 EGP – 550 EGP"   -> 490         (variable-price ranges resolve to the min)
 *   "1,870.50"            -> 1870.50
 */
export function parseEgpPrice(raw: string): number | null {
  if (!raw) return null;

  // Range strings ("X – Y", "X-Y", "X to Y"): take the lowest bound, matching
  // Amazon/marketplace convention of showing the "starting at" price.
  const rangeMatch = raw.match(/([\d.,]+)\s*(?:–|-|to)\s*([\d.,]+)/i);
  const candidate = rangeMatch ? rangeMatch[1] : raw;

  const numeric = candidate.replace(/EGP|جنيه|LE/gi, "").trim();
  const digitsOnly = numeric.match(/[\d.,]+/);
  if (!digitsOnly) return null;

  let normalized = digitsOnly[0];

  const lastComma = normalized.lastIndexOf(",");
  const lastDot = normalized.lastIndexOf(".");

  if (lastComma > -1 && lastDot > -1) {
    // Both separators present: whichever is rightmost is the decimal point.
    if (lastComma > lastDot) {
      normalized = normalized.replace(/\./g, "").replace(",", ".");
    } else {
      normalized = normalized.replace(/,/g, "");
    }
  } else if (lastComma > -1) {
    // Only a comma: treat as thousands separator (e.g. "1,250").
    normalized = normalized.replace(/,/g, "");
  } else if (lastDot > -1) {
    // Only a dot: ambiguous between "1.950" (thousands, EG convention) and
    // "1.95" (decimal). Heuristic: exactly 3 digits after the dot => thousands.
    const decimals = normalized.length - lastDot - 1;
    if (decimals === 3) {
      normalized = normalized.replace(/\./g, "");
    }
  }

  const value = Number.parseFloat(normalized);
  return Number.isFinite(value) ? value : null;
}

export function computeDiscountPercentage(
  price: number,
  oldPrice: number | null
): number | null {
  if (!oldPrice || oldPrice <= price) return null;
  return Math.round(((oldPrice - price) / oldPrice) * 100);
}

export function slugify(input: string): string {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\u0600-\u06FF]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

export async function safeGoto(
  page: Page,
  url: string,
  opts: { waitUntil?: "domcontentloaded" | "networkidle"; timeoutMs?: number } = {}
): Promise<void> {
  await withRetry(
    () =>
      page.goto(url, {
        waitUntil: opts.waitUntil ?? "domcontentloaded",
        timeout: opts.timeoutMs ?? 30_000,
      }),
    { label: `goto ${url}` }
  );
}
