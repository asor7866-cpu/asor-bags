/**
 * packages/scraper/src/lib/normalize.ts
 *
 * Single normalization entrypoint. Every scraper (Elite-Bag, BZ-Bags,
 * Raneen/Three-M) emits RawScrapedProduct; this is the only place raw rows
 * are turned into the strict UnifiedProduct the DB and API rely on.
 */

import { randomUUID } from "node:crypto";
import type { RawScrapedProduct, UnifiedProduct } from "@bags-aggregator/types/product";
import { computeDiscountPercentage, parseEgpPrice, slugify } from "./utils";
import { mapEliteCategoryToUnified } from "../scrapers/elite-bag.scraper";

export function normalizeProduct(raw: RawScrapedProduct): UnifiedProduct | null {
  const priceEgp = parseEgpPrice(raw.priceText);
  if (priceEgp === null) {
    // A product with no parseable price is unusable downstream — surface it
    // as a skipped row in ScrapeLog rather than writing a broken record.
    return null;
  }

  const oldPriceEgp = raw.oldPriceText ? parseEgpPrice(raw.oldPriceText) : null;
  const discountPercentage = computeDiscountPercentage(priceEgp, oldPriceEgp);

  const sku = raw.sourceSku ?? deriveSyntheticSku(raw);
  const categoryMapped =
    raw.sourcePlatform === "ELITE_BAG"
      ? mapEliteCategoryToUnified(raw.rawCategoryLabel)
      : "UNCATEGORIZED"; // BZ-Bags / Raneen mappers plug in here identically

  const now = new Date().toISOString();

  return {
    id: randomUUID(),
    sku,
    title: raw.title.trim(),
    slug: slugify(`${raw.title}-${sku}`),
    description: raw.descriptionHtml ? stripHtml(raw.descriptionHtml) : null,
    priceEgp,
    oldPriceEgp,
    discountPercentage,
    images: dedupe(raw.imageUrls),
    sourcePlatform: raw.sourcePlatform,
    originalUrl: raw.originalUrl,
    categoryMapped,
    inStock: raw.inStock,
    ratingAverage: raw.ratingAverage,
    ratingCount: raw.ratingCount,
    scrapedAt: now,
    updatedAt: now,
  };
}

export function normalizeBatch(raws: RawScrapedProduct[]): {
  products: UnifiedProduct[];
  skipped: RawScrapedProduct[];
} {
  const products: UnifiedProduct[] = [];
  const skipped: RawScrapedProduct[] = [];

  for (const raw of raws) {
    const normalized = normalizeProduct(raw);
    if (normalized) products.push(normalized);
    else skipped.push(raw);
  }

  return { products, skipped };
}

function deriveSyntheticSku(raw: RawScrapedProduct): string {
  // Stable across re-scrapes as long as the source URL doesn't change —
  // used as the uq_source_sku fallback for sites with no visible SKU.
  const urlPath = new URL(raw.originalUrl).pathname;
  return `SYN-${Buffer.from(urlPath).toString("base64url").slice(0, 24)}`;
}

function dedupe(items: string[]): string[] {
  return [...new Set(items)];
}

function stripHtml(html: string): string {
  return html.replace(/<[^>]*>/g, "").replace(/\s+/g, " ").trim();
}
