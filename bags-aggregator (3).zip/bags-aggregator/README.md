# Bags Aggregator — Architecture & Delivery Notes

## What's included in this delivery vs. what's next

This package contains the **4 foundational deliverables requested**:

1. Monorepo directory layout (below)
2. `prisma/schema.prisma` — unified PostgreSQL schema with composite indexes
3. `packages/scraper/src/scrapers/elite-bag.scraper.ts` — full scraper for
   Elite Bag, built against its **real, live-verified** WooCommerce/WordPress
   markup (confirmed by fetching the live site — not guessed selectors)
4. `apps/web/app/page.tsx` and `apps/web/app/search/page.tsx` — Next.js App
   Router pages with the complete sidebar-filter/sort state logic

**Not included in this pass** (called out explicitly rather than stubbed):
the NestJS/FastAPI API service, the BZ-Bags and Raneen scrapers, the
Meilisearch indexing job, and the BullMQ cron sync worker. Section 4 of the
brief asked for these four artifacts specifically — the rest of the stack
(API routes like `/api/search`, `/api/products/homepage`, `/api/suggest`
referenced by the frontend below) should be scaffolded next once you confirm
the exact response shapes you want. They're typed against
`packages/types/src/product.ts` already, so building them is a matter of
implementing the Prisma queries behind each route, not redesigning anything.

Also worth flagging: **BZ-Bags** (`bz-bags.com`) and **Raneen's Three M
brand page** could not be verified as live, stable scrape targets in the
research done earlier in this conversation — BZ appeared to have no
independent storefront (only Jumia/Amazon.eg/Facebook listings). If
`bz-bags.com` is a real, distinct site you've since confirmed, send the URL
and the second scraper follows the same pattern as `elite-bag.scraper.ts`.

## Directory layout

```
bags-aggregator/
├── apps/
│   ├── web/                          # Next.js 14 App Router frontend
│   │   └── app/
│   │       ├── page.tsx              # Homepage (SSR + ISR revalidate)
│   │       ├── search/
│   │       │   ├── page.tsx          # Search route (server: SSR initial fetch)
│   │       │   └── SearchPageClient.tsx  # Client: filter/sort hook state
│   │       └── components/
│   │           ├── ProductCard.tsx
│   │           ├── FilterSidebar.tsx
│   │           └── SearchBar.tsx
│   └── api/                          # NestJS API — NOT built in this pass
│       └── (scaffold next: /search, /products/homepage, /suggest, /sync)
│
├── packages/
│   ├── scraper/                      # Standalone worker service
│   │   └── src/
│   │       ├── scrapers/
│   │       │   └── elite-bag.scraper.ts
│   │       └── lib/
│   │           ├── utils.ts          # stealth launch, retry, price parser
│   │           └── normalize.ts      # raw → UnifiedProduct normalization
│   └── types/                        # Shared TS contracts (product shape)
│       └── src/product.ts
│
├── prisma/
│   └── schema.prisma                 # Unified Postgres schema + indexes
│
├── package.json                      # npm/pnpm workspaces root
└── README.md                         # this file
```

## How the pieces connect

1. **Scraper → Normalizer → DB.** Each site scraper (only `elite-bag` exists
   so far) emits `RawScrapedProduct[]`. `normalize.ts` turns that into
   `UnifiedProduct[]`, which a (not-yet-built) Prisma `upsert` loop writes
   into `products`, keyed on the `uq_source_sku` unique constraint so
   re-scraping updates price/stock instead of duplicating rows.
2. **API → Frontend.** `apps/web` fetches from `NEXT_PUBLIC_API_URL`
   (defaults to `http://localhost:4000`) expecting the exact
   `FacetedSearchResult` / `UnifiedProduct` shapes defined in
   `packages/types/src/product.ts`. Build the API to match those types and
   the frontend needs no changes.
3. **Search UX.** `SearchPageClient.tsx` keeps all filter/sort/page state in
   a `useReducer`, mirrors it into the URL query string on every change
   (bookmarkable, back-button-safe), and re-fetches `/api/search` on state
   change — while the sidebar's price histogram and facet counts come
   straight from the same response, so counts always match what's on screen.

## Getting it running locally (once the API is scaffolded)

```bash
# from repo root
npm install

# start Postgres + Redis (docker-compose not included in this pass)
npx prisma migrate dev --schema=prisma/schema.prisma

# run the Elite Bag scraper standalone
npm run scrape:elite --workspace=packages/scraper

# run the frontend
npm run dev --workspace=apps/web
```
