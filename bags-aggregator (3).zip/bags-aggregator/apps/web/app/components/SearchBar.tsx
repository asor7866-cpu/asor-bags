"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";

interface Suggestion {
  slug: string;
  title: string;
  priceEgp: number;
}

export function SearchBar({ initialQuery = "" }: { initialQuery?: string }) {
  const router = useRouter();
  const [query, setQuery] = useState(initialQuery);
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);

    if (query.trim().length < 2) {
      setSuggestions([]);
      return;
    }

    debounceRef.current = setTimeout(async () => {
      try {
        // Backed by the Meilisearch-fronted /api/suggest endpoint —
        // typo tolerance and ranking live server-side in Meilisearch itself.
        const res = await fetch(`/api/suggest?q=${encodeURIComponent(query)}`);
        if (!res.ok) return;
        const data: Suggestion[] = await res.json();
        setSuggestions(data);
        setIsOpen(true);
      } catch {
        // Network hiccups on autosuggest shouldn't break typing — fail silent.
        setSuggestions([]);
      }
    }, 220);

    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [query]);

  function submitSearch(term: string) {
    setIsOpen(false);
    router.push(`/search?q=${encodeURIComponent(term)}`);
  }

  return (
    <div className="relative w-full max-w-xl">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          submitSearch(query);
        }}
        className="flex overflow-hidden rounded-md border border-neutral-300"
      >
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => suggestions.length > 0 && setIsOpen(true)}
          onBlur={() => setTimeout(() => setIsOpen(false), 150)}
          placeholder="Search backpacks, crossbody bags, laptop sleeves..."
          className="w-full px-3 py-2 text-sm outline-none"
          aria-label="Search products"
        />
        <button
          type="submit"
          className="bg-amber-500 px-4 text-sm font-semibold text-white hover:bg-amber-600"
        >
          Search
        </button>
      </form>

      {isOpen && suggestions.length > 0 && (
        <ul className="absolute z-20 mt-1 w-full rounded-md border border-neutral-200 bg-white shadow-lg">
          {suggestions.map((s) => (
            <li key={s.slug}>
              <button
                type="button"
                onClick={() => submitSearch(s.title)}
                className="flex w-full items-center justify-between px-3 py-2 text-left text-sm hover:bg-neutral-50"
              >
                <span>{s.title}</span>
                <span className="text-neutral-400">{s.priceEgp.toLocaleString("en-EG")} EGP</span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
