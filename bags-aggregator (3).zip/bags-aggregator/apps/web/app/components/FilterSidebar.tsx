"use client";

import type { CategoryMapped, SourcePlatform } from "@bags-aggregator/types/product";

const SOURCE_OPTIONS: { value: SourcePlatform; label: string }[] = [
  { value: "BZ_BAGS", label: "BZ Bags" },
  { value: "ELITE_BAG", label: "Elite Bag" },
  { value: "RANEEN_THREE_M", label: "Raneen (Three M)" },
];

const CATEGORY_OPTIONS: { value: CategoryMapped; label: string }[] = [
  { value: "BACKPACKS", label: "Backpacks" },
  { value: "TRAVEL_BAGS", label: "Travel Bags" },
  { value: "CROSSBODY", label: "Crossbody" },
  { value: "HANDBAGS", label: "Handbags" },
  { value: "LAPTOP_BAGS", label: "Laptop Bags" },
  { value: "ACCESSORIES", label: "Accessories" },
];

export interface FilterState {
  minPrice: number;
  maxPrice: number;
  sources: SourcePlatform[];
  categories: CategoryMapped[];
  inStockOnly: boolean;
}

export const DEFAULT_FILTER_STATE: FilterState = {
  minPrice: 0,
  maxPrice: 5000,
  sources: [],
  categories: [],
  inStockOnly: false,
};

interface PriceBucket {
  bucketStart: number;
  bucketEnd: number;
  count: number;
}

interface FilterSidebarProps {
  filters: FilterState;
  onChange: (next: FilterState) => void;
  priceHistogram?: PriceBucket[];
  sourceFacetCounts?: Partial<Record<SourcePlatform, number>>;
  categoryFacetCounts?: Partial<Record<CategoryMapped, number>>;
}

export function FilterSidebar({
  filters,
  onChange,
  priceHistogram = [],
  sourceFacetCounts = {},
  categoryFacetCounts = {},
}: FilterSidebarProps) {
  function toggleInArray<T>(list: T[], value: T): T[] {
    return list.includes(value) ? list.filter((v) => v !== value) : [...list, value];
  }

  const maxBucketCount = Math.max(1, ...priceHistogram.map((b) => b.count));

  return (
    <aside className="w-full shrink-0 space-y-6 border-r border-neutral-200 p-4 md:w-64">
      <FilterSection title="Price">
        {priceHistogram.length > 0 && (
          <div className="mb-2 flex h-10 items-end gap-0.5">
            {priceHistogram.map((bucket) => (
              <div
                key={bucket.bucketStart}
                className="flex-1 rounded-t bg-amber-200"
                style={{ height: `${(bucket.count / maxBucketCount) * 100}%` }}
                title={`${bucket.bucketStart}–${bucket.bucketEnd} EGP: ${bucket.count} items`}
              />
            ))}
          </div>
        )}
        <div className="flex items-center gap-2">
          <input
            type="number"
            aria-label="Minimum price"
            value={filters.minPrice}
            min={0}
            max={filters.maxPrice}
            onChange={(e) =>
              onChange({ ...filters, minPrice: Number(e.target.value) || 0 })
            }
            className="w-full rounded-md border border-neutral-300 px-2 py-1 text-sm"
          />
          <span className="text-neutral-400">–</span>
          <input
            type="number"
            aria-label="Maximum price"
            value={filters.maxPrice}
            min={filters.minPrice}
            onChange={(e) =>
              onChange({ ...filters, maxPrice: Number(e.target.value) || filters.minPrice })
            }
            className="w-full rounded-md border border-neutral-300 px-2 py-1 text-sm"
          />
        </div>
        <input
          type="range"
          aria-label="Maximum price slider"
          min={0}
          max={5000}
          step={50}
          value={filters.maxPrice}
          onChange={(e) => onChange({ ...filters, maxPrice: Number(e.target.value) })}
          className="mt-2 w-full accent-amber-500"
        />
      </FilterSection>

      <FilterSection title="Source Store">
        {SOURCE_OPTIONS.map((opt) => (
          <label key={opt.value} className="flex cursor-pointer items-center justify-between py-1 text-sm">
            <span className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={filters.sources.includes(opt.value)}
                onChange={() =>
                  onChange({ ...filters, sources: toggleInArray(filters.sources, opt.value) })
                }
                className="h-4 w-4 rounded accent-amber-500"
              />
              {opt.label}
            </span>
            <span className="text-xs text-neutral-400">{sourceFacetCounts[opt.value] ?? 0}</span>
          </label>
        ))}
      </FilterSection>

      <FilterSection title="Category">
        {CATEGORY_OPTIONS.map((opt) => (
          <label key={opt.value} className="flex cursor-pointer items-center justify-between py-1 text-sm">
            <span className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={filters.categories.includes(opt.value)}
                onChange={() =>
                  onChange({ ...filters, categories: toggleInArray(filters.categories, opt.value) })
                }
                className="h-4 w-4 rounded accent-amber-500"
              />
              {opt.label}
            </span>
            <span className="text-xs text-neutral-400">{categoryFacetCounts[opt.value] ?? 0}</span>
          </label>
        ))}
      </FilterSection>

      <FilterSection title="Availability">
        <label className="flex cursor-pointer items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={filters.inStockOnly}
            onChange={() => onChange({ ...filters, inStockOnly: !filters.inStockOnly })}
            className="h-4 w-4 rounded accent-amber-500"
          />
          In stock only
        </label>
      </FilterSection>

      <button
        type="button"
        onClick={() => onChange(DEFAULT_FILTER_STATE)}
        className="w-full rounded-md border border-neutral-300 py-1.5 text-sm text-neutral-600 hover:bg-neutral-50"
      >
        Clear all filters
      </button>
    </aside>
  );
}

function FilterSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="border-b border-neutral-100 pb-4">
      <h3 className="mb-2 text-sm font-semibold text-neutral-900">{title}</h3>
      {children}
    </div>
  );
}
