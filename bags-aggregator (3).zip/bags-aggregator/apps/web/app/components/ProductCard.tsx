"use client";

import Image from "next/image";
import Link from "next/link";
import type { UnifiedProduct } from "@bags-aggregator/types/product";

const SOURCE_LABELS: Record<UnifiedProduct["sourcePlatform"], string> = {
  BZ_BAGS: "Via BZ Bags",
  ELITE_BAG: "Via Elite Bag",
  RANEEN_THREE_M: "Via Raneen · Three M",
};

interface ProductCardProps {
  product: UnifiedProduct;
}

export function ProductCard({ product }: ProductCardProps) {
  const primaryImage = product.images[0] ?? "/placeholder-product.svg";

  return (
    <div className="group flex flex-col overflow-hidden rounded-lg border border-neutral-200 bg-white transition-shadow hover:shadow-md">
      <Link href={`/product/${product.slug}`} className="relative block aspect-square bg-neutral-50">
        <Image
          src={primaryImage}
          alt={product.title}
          fill
          loading="lazy"
          sizes="(max-width: 768px) 50vw, (max-width: 1200px) 25vw, 20vw"
          className="object-contain p-4 transition-transform duration-200 group-hover:scale-105"
        />
        {!product.inStock && (
          <span className="absolute left-2 top-2 rounded bg-neutral-900/80 px-2 py-1 text-xs font-medium text-white">
            Out of stock
          </span>
        )}
        {product.discountPercentage !== null && (
          <span className="absolute right-2 top-2 rounded bg-red-600 px-2 py-1 text-xs font-bold text-white">
            -{product.discountPercentage}%
          </span>
        )}
      </Link>

      <div className="flex flex-1 flex-col gap-1.5 p-3">
        <span className="w-fit rounded-full bg-amber-50 px-2 py-0.5 text-[11px] font-medium text-amber-700">
          {SOURCE_LABELS[product.sourcePlatform]}
        </span>

        <Link
          href={`/product/${product.slug}`}
          className="line-clamp-2 text-sm font-medium text-neutral-800 hover:text-amber-700"
        >
          {product.title}
        </Link>

        {product.ratingAverage !== null && (
          <div className="flex items-center gap-1 text-xs text-neutral-500">
            <StarRow value={product.ratingAverage} />
            {product.ratingCount !== null && <span>({product.ratingCount})</span>}
          </div>
        )}

        <div className="mt-auto flex items-baseline gap-2 pt-1">
          <span className="text-lg font-bold text-neutral-900">
            {product.priceEgp.toLocaleString("en-EG")} EGP
          </span>
          {product.oldPriceEgp !== null && (
            <span className="text-sm text-neutral-400 line-through">
              {product.oldPriceEgp.toLocaleString("en-EG")} EGP
            </span>
          )}
        </div>

        <div className="mt-2 flex gap-2">
          <Link
            href={`/product/${product.slug}`}
            className="flex-1 rounded-md border border-neutral-300 px-3 py-1.5 text-center text-xs font-medium text-neutral-700 hover:bg-neutral-50"
          >
            View details
          </Link>
          <a
            href={product.originalUrl}
            target="_blank"
            rel="noopener noreferrer nofollow"
            className="flex-1 rounded-md bg-amber-500 px-3 py-1.5 text-center text-xs font-semibold text-white hover:bg-amber-600"
          >
            View deal
          </a>
        </div>
      </div>
    </div>
  );
}

function StarRow({ value }: { value: number }) {
  const rounded = Math.round(value);
  return (
    <span aria-label={`${value} out of 5 stars`}>
      {"★".repeat(rounded)}
      {"☆".repeat(5 - rounded)}
    </span>
  );
}
