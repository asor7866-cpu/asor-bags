import type { FacetedSearchResult } from "@bags-aggregator/types/product";
import { SearchPageClient } from "./SearchPageClient";

export const dynamic = "force-dynamic"; // search results are query-dependent, never statically cached

const API_BASE = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:4000";

interface SearchPageProps {
  searchParams: Record<string, string | string[] | undefined>;
}

const EMPTY_RESULT: FacetedSearchResult = {
  items: [],
  total: 0,
  page: 1,
  pageSize: 24,
  facets: {
    sources: { BZ_BAGS: 0, ELITE_BAG: 0, RANEEN_THREE_M: 0 },
    categories: {
      BACKPACKS: 0,
      TRAVEL_BAGS: 0,
      CROSSBODY: 0,
      HANDBAGS: 0,
      LAPTOP_BAGS: 0,
      ACCESSORIES: 0,
      UNCATEGORIZED: 0,
    },
    priceHistogram: [],
  },
};

function buildApiParams(searchParams: SearchPageProps["searchParams"]): URLSearchParams {
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(searchParams)) {
    if (typeof value === "string") params.set(key, value);
  }
  params.set("pageSize", "24");
  return params;
}

async function fetchInitialResults(
  searchParams: SearchPageProps["searchParams"],
): Promise<FacetedSearchResult> {
  const params = buildApiParams(searchParams);

  try {
    // SSR fetch: the first paint of /search always reflects real data,
    // matching the sub-second "feels instant" requirement — no client-side
    // loading spinner on first load, only on subsequent filter changes.
    const res = await fetch(`${API_BASE}/api/search?${params.toString()}`, {
      cache: "no-store",
    });
    if (!res.ok) return EMPTY_RESULT;
    return await res.json();
  } catch {
    return EMPTY_RESULT;
  }
}

export default async function SearchPage({ searchParams }: SearchPageProps) {
  const initialResult = await fetchInitialResults(searchParams);
  return <SearchPageClient initialResult={initialResult} />;
}
