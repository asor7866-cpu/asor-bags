"use client";

import { useCallback, useEffect, useMemo, useReducer, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import type {
  CategoryMapped,
  FacetedSearchResult,
  SourcePlatform,
  UnifiedProduct,
} from "@bags-aggregator/types/product";
import { ProductCard } from "../components/ProductCard";
import { SearchBar } from "../components/SearchBar";
import { DEFAULT_FILTER_STATE, FilterSidebar, type FilterState } from "../components/FilterSidebar";

type SortOption = "PRICE_ASC" | "PRICE_DESC" | "TOP_RATED" | "NEWEST";

interface SearchState {
  query: string;
  filters: FilterState;
  sort: SortOption;
  page: number;
}

type SearchAction =
  | { type: "SET_QUERY"; query: string }
  | { type: "SET_FILTERS"; filters: FilterState }
  | { type: "SET_SORT"; sort: SortOption }
  | { type: "SET_PAGE"; page: number }
  | { type: "HYDRATE_FROM_URL"; state: SearchState };

function searchReducer(state: SearchState, action: SearchAction): SearchState {
  switch (action.type) {
    case "SET_QUERY":
      return { ...state, query: action.query, page: 1 };
    case "SET_FILTERS":
      return { ...state, filters: action.filters, page: 1 };
    case "SET_SORT":
      return { ...state, sort: action.sort, page: 1 };
    case "SET_PAGE":
      return { ...state, page: action.page };
    case "HYDRATE_FROM_URL":
      return action.state;
    default:
      return state;
  }
}

function stateToSearchParams(state: SearchState): URLSearchParams {
  const params = new URLSearchParams();
  if (state.query) params.set("q", state.query);
  if (state.filters.minPrice > 0) params.set("minPrice", String(state.filters.minPrice));
  if (state.filters.maxPrice < 5000) params.set("maxPrice", String(state.filters.maxPrice));
  if (state.filters.sources.length) params.set("sources", state.filters.sources.join(","));
  if (state.filters.categories.length) params.set("categories", state.filters.categories.join(","));
  if (state.filters.inStockOnly) params.set("inStock", "1");
  if (state.sort !== "NEWEST") params.set("sort", state.sort);
  if (state.page > 1) params.set("page", String(state.page));
  return params;
}

function searchParamsToState(params: URLSearchParams): SearchState {
  return {
    query: params.get("q") ?? "",
    filters: {
      minPrice: Number(params.get("minPrice") ?? 0),
      maxPrice: Number(params.get("maxPrice") ?? 5000),
      sources: (params.get("sources")?.split(",").filter(Boolean) ?? []) as SourcePlatform[],
      categories: (params.get("categories")?.split(",").filter(Boolean) ?? []) as CategoryMapped[],
      inStockOnly: params.get("inStock") === "1",
    },
    sort: (params.get("sort") as SortOption) ?? "NEWEST",
    page: Number(params.get("page") ?? 1),
  };
}

interface SearchPageClientProps {
  initialResult: FacetedSearchResult;
}

export function SearchPageClient({ initialResult }: SearchPageClientProps) {
  const router = useRouter();
  const searchParams = useSearchParams();

  const [state, dispatch] = useReducer(
    searchReducer,
    searchParamsToState(searchParams),
  );

  const [result, setResult] = useState<FacetedSearchResult>(initialResult);

  // Keep the URL in sync with state so filters are shareable/bookmarkable
  // and back/forward navigation restores the exact filter combination.
  useEffect(() => {
    const params = stateToSearchParams(state);
    router.replace(`/search?${params.toString()}`, { scroll: false });
  }, [state, router]);

  // Re-fetch whenever the *effective* query changes. Debounced implicitly
  // by the fact that filter checkboxes/sliders don't fire on every keystroke
  // (free-text query changes go through SearchBar's own debounce instead).
  useEffect(() => {
    const params = stateToSearchParams(state);
    let cancelled = false;

    (async () => {
      try {
        const res = await fetch(`/api/search?${params.toString()}`);
        if (!res.ok) return;
        const data: FacetedSearchResult = await res.json();
        if (!cancelled) setResult(data);
      } catch {
        // Keep showing the last good result set rather than clearing the grid.
      }
    })();

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state]);

  const setFilters = useCallback(
    (filters: FilterState) => dispatch({ type: "SET_FILTERS", filters }),
    [],
  );

  const setSort = useCallback(
    (sort: SortOption) => dispatch({ type: "SET_SORT", sort }),
    [],
  );

  const setPage = useCallback((page: number) => dispatch({ type: "SET_PAGE", page }), []);

  const totalPages = useMemo(
    () => Math.max(1, Math.ceil(result.total / result.pageSize)),
    [result.total, result.pageSize],
  );

  return (
    <main className="mx-auto max-w-7xl px-4 pb-16">
      <div className="sticky top-0 z-10 -mx-4 border-b border-neutral-200 bg-white/95 px-4 py-3 backdrop-blur">
        <SearchBar initialQuery={state.query} />
      </div>

      <div className="flex flex-col gap-6 py-6 md:flex-row">
        <FilterSidebar
          filters={state.filters}
          onChange={setFilters}
          priceHistogram={result.facets.priceHistogram}
          sourceFacetCounts={result.facets.sources}
          categoryFacetCounts={result.facets.categories}
        />

        <div className="flex-1">
          <div className="mb-4 flex items-center justify-between">
            <p className="text-sm text-neutral-600">
              {result.total.toLocaleString("en-EG")} results
              {state.query && (
                <>
                  {" "}
                  for <span className="font-medium text-neutral-900">&quot;{state.query}&quot;</span>
                </>
              )}
            </p>
            <SortDropdown value={state.sort} onChange={setSort} />
          </div>

          {result.items.length === 0 ? (
            <EmptyState />
          ) : (
            <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
              {result.items.map((product: UnifiedProduct) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}

          <Pagination page={state.page} totalPages={totalPages} onChange={setPage} />
        </div>
      </div>
    </main>
  );
}

function SortDropdown({
  value,
  onChange,
}: {
  value: SortOption;
  onChange: (sort: SortOption) => void;
}) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value as SortOption)}
      aria-label="Sort products"
      className="rounded-md border border-neutral-300 px-3 py-1.5 text-sm"
    >
      <option value="NEWEST">Newest Arrivals</option>
      <option value="PRICE_ASC">Price: Low to High</option>
      <option value="PRICE_DESC">Price: High to Low</option>
      <option value="TOP_RATED">Top Rated</option>
    </select>
  );
}

function Pagination({
  page,
  totalPages,
  onChange,
}: {
  page: number;
  totalPages: number;
  onChange: (page: number) => void;
}) {
  if (totalPages <= 1) return null;

  return (
    <div className="mt-8 flex items-center justify-center gap-2">
      <button
        type="button"
        disabled={page <= 1}
        onClick={() => onChange(page - 1)}
        className="rounded-md border border-neutral-300 px-3 py-1.5 text-sm disabled:opacity-40"
      >
        Previous
      </button>
      <span className="text-sm text-neutral-600">
        Page {page} of {totalPages}
      </span>
      <button
        type="button"
        disabled={page >= totalPages}
        onClick={() => onChange(page + 1)}
        className="rounded-md border border-neutral-300 px-3 py-1.5 text-sm disabled:opacity-40"
      >
        Next
      </button>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="flex flex-col items-center gap-2 py-24 text-center text-neutral-500">
      <p className="text-lg font-medium text-neutral-700">No products match these filters</p>
      <p className="text-sm">Try widening the price range or clearing a category filter.</p>
    </div>
  );
}

export { DEFAULT_FILTER_STATE };
