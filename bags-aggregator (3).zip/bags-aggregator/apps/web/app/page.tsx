import Link from "next/link";
import type { UnifiedProduct } from "@bags-aggregator/types/product";
import { ProductCard } from "./components/ProductCard";
import { SearchBar } from "./components/SearchBar";

export const revalidate = 300; // ISR: refresh homepage data every 5 minutes

const API_BASE = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:4000";

async function getHomepageData(): Promise<{
  featured: UnifiedProduct[];
  newest: UnifiedProduct[];
  topRated: UnifiedProduct[];
}> {
  // Server-side fetch — this runs at request time on the server (SSR for
  // this route) so the client never sees the API origin or waits on it.
  const res = await fetch(`${API_BASE}/api/products/homepage`, {
    next: { revalidate },
  });

  if (!res.ok) {
    // Fail soft: an empty homepage is recoverable, a thrown error isn't.
    return { featured: [], newest: [], topRated: [] };
  }

  return res.json();
}

export default async function HomePage() {
  const { featured, newest, topRated } = await getHomepageData();

  return (
    <main className="mx-auto max-w-7xl px-4 pb-16">
      <section className="flex flex-col items-center gap-4 py-10 text-center">
        <h1 className="text-3xl font-bold text-neutral-900 md:text-4xl">
          Every bag brand in Egypt. One search.
        </h1>
        <p className="max-w-2xl text-neutral-600">
          Compare backpacks, crossbody bags, and laptop bags from Elite Bag, BZ Bags,
          and Raneen&apos;s Three M collection — prices and stock synced daily.
        </p>
        <SearchBar />
      </section>

      <HomeSection title="Featured products" href="/search?sort=NEWEST" products={featured} />
      <HomeSection title="Newest arrivals" href="/search?sort=NEWEST" products={newest} />
      <HomeSection title="Top rated" href="/search?sort=TOP_RATED" products={topRated} />
    </main>
  );
}

function HomeSection({
  title,
  href,
  products,
}: {
  title: string;
  href: string;
  products: UnifiedProduct[];
}) {
  if (products.length === 0) return null;

  return (
    <section className="py-6">
      <div className="mb-3 flex items-center justify-between">
        <h2 className="text-lg font-semibold text-neutral-900">{title}</h2>
        <Link href={href} className="text-sm font-medium text-amber-600 hover:underline">
          See all
        </Link>
      </div>
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4 lg:grid-cols-5">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </section>
  );
}
